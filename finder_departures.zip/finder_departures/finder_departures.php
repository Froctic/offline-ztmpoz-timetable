<?php

/**
 * @package Finder Departures ZTM GTFS
 * @version 1.0.0
 */
/*
Plugin Name: Finder Departures ZTM GTFS
Plugin URI: https://gamejolt.com/@Froctic
Description: Plugin sluzacy do wyswietlania rozkladow jazdy ZTM Poznan w trybie offline.
             Wykorzystuje dane GTFS przekonwertowane do bazy SQLite (.db).
             Baza jest tworzona za pomoca aplikacji ZTM Poznan GTFS Editor. 
            (https://gamejolt.com/games/SRG-5000p/834902)
Author: Froctic / Michal Postemskii (Mykhailo Postemskyi)
Version: 1.0.0
Author URI: https://gamejolt.com/@Froctic
Text Domain: finder-departures-ztm-gtfs
*/

//podlaczamy baze_ztm (20261106 - 20261127)
$db = new PDO('sqlite:' . __DIR__ . '/gtfs_data.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//szukamy dzien dzisiejszy (service_id z tabeli calendar)
$today = new DateTime('now', new DateTimeZone('Europe/Warsaw'));

$date = $today->format('Ymd');
$isoDate = $today->format('Y-m-d');

$sql_calendar = "
    SELECT service_id
    FROM calendar
    WHERE start_date <= :date
      AND end_date >= :date
      AND CASE CAST(strftime('%w', :iso_date) AS INTEGER)
          WHEN 0 THEN sunday
          WHEN 1 THEN monday
          WHEN 2 THEN tuesday
          WHEN 3 THEN wednesday
          WHEN 4 THEN thursday
          WHEN 5 THEN friday
          WHEN 6 THEN saturday
      END = 1
";

$stmt = $db->prepare($sql_calendar);
$stmt->execute([
    'date' => $date,
    'iso_date' => $isoDate
]);
$serviceIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
//echo "Date: $isoDate\n";
//echo "Active service IDs:\n";
//print_r($serviceIds); //Date: 2026-11-09 Active service IDs: Array ( [0] => 5 )

//Bierzemy kody przystankow:
// DBBUK02 - w jedna strone | Dabrowa/Szkolna -> Ogrody
// DBBUK01,DBBUK02 w dwie strony | Dabrowa/Szkolna -> Dopiewo/Dw. Kolejowy
// KOCEN01,KOCEN02,KOZAK01,KOZAK02 - 'Wezel Przesiadkowy' Komorniki/Centrum x Komorniki/Zakl. Wirenka | -> Gorczyn PKM x Komorniki x Konarzewo x Rosnowko x Junikowo
$codes = $_GET['code'] ?? '';
$codes = array_filter(array_map('trim', explode(',', $codes)));
$conditions = [];
foreach ($codes as $code) {
    $conditions[] = "s.stop_code = " . $db->quote($code);
}
$przystnaki = implode(' OR ', $conditions);
// echo $przystnaki;
// s.stop_code = 'DBBUK02'
// s.stop_code = 'DBBUK01' OR s.stop_code = 'DBBUK02'
// s.stop_code = 'KOCEN01' OR s.stop_code = 'KOCEN02' OR s.stop_code = 'KOZAK01' OR s.stop_code = 'KOZAK02'

//sprawdzamy czy wszystko gra
$serviceId = $serviceIds[0] ?? null;
if ($serviceId === null) {
    print_r("Brak aktywnego rozkladu jazdy na dzisiaj. Sprawdz, czy w tabeli 'calendar' jest rozklad na dzisiaj, albo sprawdz start_date i end_date.");
    die('today_is_not_exist_in_data_base');
}
if (empty($codes)) {
    die('Nie podano kodu przystanku. [code_empty]');
}
$placeholders = implode(',', array_fill(0, count($codes), '?'));
$sql_check_stops = "
    SELECT stop_code
    FROM stops
    WHERE stop_code IN ($placeholders)
";
$stmt_check = $db->prepare($sql_check_stops);
$stmt_check->execute($codes);
$existingCodes = $stmt_check->fetchAll(PDO::FETCH_COLUMN);
if (empty($existingCodes)) {
    die('Nie znaleziono podanych przystankow w bazie danych. [stops_not_found]');
}

//szukamy odjazdy na ten dzien dla tego/tych przystankow
$sql_find_depart = "
    SELECT
        rt.route_id AS Line,
        trps.trip_headsign AS Direction,
        printf('%02d:%02d',
            CAST(substr(stptms.departure_time, 1, 2) AS INTEGER) % 24,
            CAST(substr(stptms.departure_time, 4, 2) AS INTEGER)
        ) AS Departure,
        trps.trip_id AS TRIPID
    FROM routes rt
    JOIN trips trps ON trps.route_id = rt.route_id
    JOIN stop_times stptms ON stptms.trip_id = trps.trip_id
    JOIN stops s ON s.stop_id = stptms.stop_id
    WHERE ($przystnaki)
      AND trps.service_id = :service_id
    ORDER BY Departure;
";

$stmt_deps = $db->prepare($sql_find_depart);
$stmt_deps->execute(['service_id' => $serviceId]);

$departures = $stmt_deps->fetchAll(PDO::FETCH_ASSOC);
// Tabliczka do konsoli
echo "<script>";
echo "console.log(" . json_encode($departures, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) . ");";
echo "</script>";
//czemu json? api ztmu - wysyla dane odjazdow w typie JSON, do tych 3ch przykladow daje link na dowod:
//https://www.ztm.poznan.pl/wp-json/pozitiveztm/v1/getTransferHub?code=DBBUK02
//https://www.ztm.poznan.pl/wp-json/pozitiveztm/v1/getTransferHub?code=DBBUK01,DBBUK02
//https://www.ztm.poznan.pl/wp-json/pozitiveztm/v1/getTransferHub?code=KOCEN01,KOCEN02,KOZAK01,KOZAK02
?>

<!-- Tablicka nizej to wynik szukania/robiona wzorowo i czasowo, wynik bedzie nadawany jako wartosc do skryptu ktory wysiwetla tablice -->
<table border="1" cellpadding="8">
    <tr>
        <th>Linia</th>
        <th>Kierunek</th>
        <th>Odjazd</th>
        <th>Trip ID</th>
    </tr>

    <?php foreach ($departures as $row): ?>
        <tr>
            <td><?= htmlspecialchars($row['Line']) ?></td>
            <td><?= htmlspecialchars($row['Direction']) ?></td>
            <td><?= htmlspecialchars($row['Departure']) ?></td>
            <td><?= htmlspecialchars($row['TRIPID']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>